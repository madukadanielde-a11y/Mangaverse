
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import pg from 'pg';
import crypto from 'crypto';

const { Pool } = pg;
const app = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:3000';

if (!JWT_SECRET) throw new Error('JWT_SECRET is required');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(helmet());
app.use(cors({ origin: CLIENT_ORIGIN, credentials: true }));
app.use(express.json({ limit: '2mb' }));

const authLimiter = rateLimit({ windowMs: 15*60*1000, limit: 50, standardHeaders: true, legacyHeaders: false });
app.use('/api/auth', authLimiter);

function sign(user) {
  return jwt.sign({ sub: user.id, email: user.email, name: user.display_name }, JWT_SECRET, { expiresIn: '7d' });
}
function requireAuth(req,res,next) {
  const raw = req.headers.authorization || '';
  if (!raw.startsWith('Bearer ')) return res.status(401).json({error:'Authentication required'});
  try { req.auth = jwt.verify(raw.slice(7), JWT_SECRET); next(); }
  catch { res.status(401).json({error:'Invalid or expired session'}); }
}

app.get('/api/health', (_,res)=>res.json({ok:true}));

app.post('/api/auth/signup', async (req,res)=>{
  try {
    const {name,email,password}=req.body;
    const normalized=String(email||'').trim().toLowerCase();
    if(!name || !normalized || !password || password.length<8) return res.status(400).json({error:'Name, email and an 8+ character password are required'});
    const exists=await pool.query('SELECT id FROM users WHERE email=$1',[normalized]);
    if(exists.rowCount) return res.status(409).json({error:'Email is already registered'});
    const hash=await bcrypt.hash(password,12);
    const id=crypto.randomUUID();
    const r=await pool.query(
      `INSERT INTO users(id,display_name,email,password_hash,email_verified)
       VALUES($1,$2,$3,$4,false)
       RETURNING id,display_name,email,email_verified,created_at`,
      [id,String(name).trim(),normalized,hash]
    );
    const user=r.rows[0];
    // Production: create a short-lived verification token, hash it, store it,
    // then email the raw token through an email provider.
    res.status(201).json({user,token:sign(user),verificationRequired:true});
  } catch(e) { console.error(e);res.status(500).json({error:'Unable to create account'}); }
});

app.post('/api/auth/login', async (req,res)=>{
  try {
    const email=String(req.body.email||'').trim().toLowerCase();
    const password=String(req.body.password||'');
    const r=await pool.query('SELECT id,display_name,email,password_hash,email_verified FROM users WHERE email=$1',[email]);
    if(!r.rowCount) return res.status(401).json({error:'Invalid email or password'});
    const u=r.rows[0];
    if(!(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:'Invalid email or password'});
    const user={id:u.id,display_name:u.display_name,email:u.email,email_verified:u.email_verified};
    res.json({user,token:sign(user)});
  } catch(e) { res.status(500).json({error:'Unable to sign in'}); }
});

app.get('/api/me',requireAuth,async(req,res)=>{
  const r=await pool.query(
    `SELECT id,display_name,email,email_verified,avatar_url,bio,created_at
     FROM users WHERE id=$1`,[req.auth.sub]);
  if(!r.rowCount) return res.status(404).json({error:'User not found'});
  res.json({user:r.rows[0]});
});

app.patch('/api/me',requireAuth,async(req,res)=>{
  const {displayName,avatarUrl,bio}=req.body;
  const r=await pool.query(
    `UPDATE users
     SET display_name=COALESCE($1,display_name),
         avatar_url=COALESCE($2,avatar_url),
         bio=COALESCE($3,bio)
     WHERE id=$4
     RETURNING id,display_name,email,email_verified,avatar_url,bio,created_at`,
    [displayName||null,avatarUrl||null,bio||null,req.auth.sub]);
  res.json({user:r.rows[0]});
});

app.listen(PORT,()=>console.log(`MangaVerse API running on port ${PORT}`));
