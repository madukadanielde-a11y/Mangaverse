# MangaVerse Supabase connection

1. Open `client/supabase-config.js`.
2. Replace `YOUR_PROJECT_URL` with your Supabase Project URL.
3. Replace `YOUR_PUBLISHABLE_KEY` with your Supabase Publishable/anon key.
4. Never use the `service_role` or other secret key in the browser.
5. Serve the `client` folder with a static server, for example:
   `npx serve client -l 3000`
6. Open the displayed URL.

The Sign Up, Sign In, Sign Out, Forgot Password and session/profile UI now use Supabase Auth.

Next production step: create a `public.profiles` row from each Supabase Auth user and add RLS policies so bookmarks, comments, reading progress and submissions are tied to `auth.uid()`.
