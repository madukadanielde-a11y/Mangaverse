
# Deployment checklist

[ ] Create production PostgreSQL database
[ ] Run schema.sql
[ ] Deploy server and set environment variables
[ ] Deploy client
[ ] Connect client API base URL to backend
[ ] Configure custom domain + HTTPS
[ ] Add email provider and verification/reset emails
[ ] Add Paystack/Flutterwave backend integration
[ ] Add object storage/CDN for chapter images
[ ] Add admin roles and authorization
[ ] Verify licensing before publication
[ ] Test signup/login/logout/password reset
[ ] Test reader, comments, bookmarks and progress
[ ] Add monitoring/backups
