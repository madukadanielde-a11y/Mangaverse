# MangaVerse — Supabase Connected

Your Supabase Project URL and Publishable key have already been added to:
client/supabase-config.js

Do not add a service_role/secret key to the browser.

To run the site, serve the `client` folder with a static web server.
